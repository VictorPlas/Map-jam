﻿using System.Collections.Generic;
using UnityEngine;

public class ButtonBehaviour : MonoBehaviour
{
   private AudioSource audio;
	public List<AudioClip> clips;

	/*
	* 
	* 
	* 
	* 
	* 
	*/

	private void Start()
	{
		audio = GetComponent<AudioSource>();
	}

	public void OnClickPlay(){
		audio.clip = clips[Random.Range(0, 3)];
		audio.Play();
	}

	public void OnMouseEnter() {

		// 
		
		if(!audio.isPlaying){
			audio.clip = clips[Random.Range(0,3)];
			audio.Play();
		}

	}


}

﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;

public enum State { Press_start, Menu, Options };

public class MenuBehaviour : MonoBehaviour
{
    private State state = State.Press_start;
	public GameObject press_start;
	public List<GameObject> menu_buttons;
    public AudioClip[] back;
	public AudioClip[] enter;
	public AudioClip[] start;
	public GameObject music_background;
	public GameObject transition;

    public void show_menu_buttons(){
		for(int i=0; i< menu_buttons.Count; i++) menu_buttons[i].SetActive(true);
	}
	public void hide_menu_buttons(){
		for (int i = 0; i < menu_buttons.Count; i++) menu_buttons[i].SetActive(false);
	}

	public void Start_game(){
		StartCoroutine(Start_game_());
	}

	public IEnumerator Start_game_(){
		GetComponent<AudioSource>().clip = start[Random.Range(0, 2)];
		GetComponent<AudioSource>().Play();
		music_background.SetActive(false);
		yield return new WaitWhile(() => GetComponent<AudioSource>().isPlaying);
		transition.SetActive(true);
		yield return new WaitForSeconds(0.3f);
		SceneManager.LoadScene(0);
	}

	public void Options(){
		state = State.Options;
		hide_menu_buttons();
		GetComponent<AudioSource>().clip = enter[Random.Range(0, 2)];
		GetComponent<AudioSource>().Play();
	}
	
	public void hide_options(){
		
	}

    void Update()
    {
        if((Input.GetKeyDown(KeyCode.KeypadEnter) || Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.Space) && state == State.Press_start)){
			state = State.Menu;
			press_start.SetActive(false);
			show_menu_buttons();
			GetComponent<AudioSource>().clip = enter[Random.Range(0, 2)];
			GetComponent<AudioSource>().Play();
		}
		if(Input.GetKeyDown(KeyCode.Escape)){
			if(state == State.Menu){
				press_start.SetActive(true);
				hide_menu_buttons();
				state = State.Press_start;
				GetComponent<AudioSource>().clip = back[Random.Range(0, 2)];
				GetComponent<AudioSource>().Play();
			}
			if (state == State.Options) {
				hide_options();
				show_menu_buttons();
				state = State.Menu;
				GetComponent<AudioSource>().clip = back[Random.Range(0,2)];
				GetComponent<AudioSource>().Play();
			}
		}  
	}
}

﻿using UnityEngine;

public enum PlayerStates { None, Map };

public class PlayerBehaviour : MonoBehaviour
{

// private:

	private PlayerStates state = PlayerStates.None;
	private const float speed = 1f;
	private Animator animator;
	private bool wall_collision;

	// monobehaviour functions:
		private void Start() {

			animator = GetComponent<Animator>();
			Transform spawn = GameObject.Find("Spawn").transform;
			transform.position = new Vector3(spawn.position.x, spawn.position.y, transform.position.z);

		}
		private void Update()
		{

			// Open map or close map
			if(Input.GetKeyDown(KeyCode.M) && (!Map.GetComponent<AudioSource>().isPlaying)) swap_state();

			if (state == PlayerStates.None) {

				Map.SetActive(false);

				// PLAYER MOVEMENT AND ANIMATIONS
				if (Input.GetKeyDown(KeyCode.W)) {
					GetComponent<SpriteRenderer>().sprite = move_sprites[1];
				}
				if (Input.GetKeyDown(KeyCode.S)) {
					GetComponent<SpriteRenderer>().sprite = move_sprites[0];
				}
				if (Input.GetKeyDown(KeyCode.A)) {
					GetComponent<SpriteRenderer>().sprite = move_sprites[2];
				}
				if (Input.GetKeyDown(KeyCode.D)) {
					GetComponent<SpriteRenderer>().sprite = move_sprites[2];
				}

				if (Input.GetKey(KeyCode.W)){
					if (!GetComponent<AudioSource>().isPlaying) {
							
						if (wall_collision)
						{
							GetComponent<AudioSource>().clip = wall;
							GetComponent<AudioSource>().Play();
						}else{

						GetComponent<AudioSource>().clip = step;
						GetComponent<AudioSource>().Play();
						}
					}
					GetComponent<SpriteRenderer>().flipX = false;
					transform.position += Vector3.up * (speed) * Time.deltaTime;
					animator.SetBool("up",true);
					animator.SetBool("down", false);
					animator.SetBool("left", false);
					animator.SetBool("right", false);
					animator.SetBool("idle", false);
					 
				}
				else if (Input.GetKey(KeyCode.S)){
					if (!GetComponent<AudioSource>().isPlaying) {
							
						if (wall_collision)
						{
							GetComponent<AudioSource>().clip = wall;
							GetComponent<AudioSource>().Play();
						}else{

						GetComponent<AudioSource>().clip = step;
						GetComponent<AudioSource>().Play();
						}
					}
					GetComponent<SpriteRenderer>().flipX = false;
					transform.position += Vector3.down * (speed) * Time.deltaTime;
					animator.SetBool("down", true);
					animator.SetBool("up", false);
					animator.SetBool("left", false);
					animator.SetBool("right", false);
					animator.SetBool("idle", false);
					 
				}
				else if (Input.GetKey(KeyCode.A)){
					if (!GetComponent<AudioSource>().isPlaying) {
							
						if (wall_collision)
						{
							GetComponent<AudioSource>().clip = wall;
							GetComponent<AudioSource>().Play();
						}else{

						GetComponent<AudioSource>().clip = step;
						GetComponent<AudioSource>().Play();
						}
					}
					GetComponent<SpriteRenderer>().flipX = true;
					transform.position += Vector3.left * (speed) * Time.deltaTime;
					animator.SetBool("left", true);
					animator.SetBool("up", false);
					animator.SetBool("down", false);
					animator.SetBool("right", false);
					animator.SetBool("idle", false);
						
				}
				else if (Input.GetKey(KeyCode.D)){
					if (!GetComponent<AudioSource>().isPlaying) {
							
						if (wall_collision)
						{
							GetComponent<AudioSource>().clip = wall;
							GetComponent<AudioSource>().Play();
						}else {

						GetComponent<AudioSource>().clip = step;
						GetComponent<AudioSource>().Play();
						}
					}
					GetComponent<SpriteRenderer>().flipX = false;
					transform.position += Vector3.right * (speed) * Time.deltaTime;
					animator.SetBool("right", true);
					animator.SetBool("up", false);
					animator.SetBool("down", false);
					animator.SetBool("left", false);
					animator.SetBool("idle", false);

				}
				else {
					animator.SetBool("right", false);
					animator.SetBool("up", false);
					animator.SetBool("down", false);
					animator.SetBool("left", false);
					animator.SetBool("idle",true);
					
				}

			}
			else if (state == PlayerStates.Map)
			{

				Map.SetActive(true);

			}
		}

// public:
		public Sprite[] move_sprites;
		public GameObject Map;
		public AudioClip step;
		public AudioClip wall;
		public GameObject room_center;
		public GameObject transition;

		public void swap_state(){
			if(state == PlayerStates.None){
				Map.GetComponent<MapBehaviour>().player_position.transform.position = Map.GetComponent<MapBehaviour>().map_position(transform.position);
				state = PlayerStates.Map;
			}
			else state = PlayerStates.None;
		}


	private void OnTriggerStay2D(Collider2D collision)
	{
		if (collision.gameObject.tag == "wall")
		{
			wall_collision = true;
		}
		else wall_collision = false;
	}

	private void OnTriggerEnter2D(Collider2D collision)
	{
		
		if (collision.gameObject.tag == "Terrain"){
			room_center.transform.position = new Vector3(collision.gameObject.transform.position.x, collision.gameObject.transform.position.y);
			Map.GetComponent<MapBehaviour>().change_offset(room_center.transform.position);
			Map.GetComponent<MapBehaviour>().modifie_door_position(collision.gameObject.GetComponent<TerrainBehaviour>().door_position);
			transition.transform.position = room_center.transform.position;
			transition.SetActive(false);
			transition.SetActive(true);

		}

	}

}

﻿using UnityEngine;

public class Door_Behaviour : MonoBehaviour
{
    public GameObject next;
	public AudioClip sound;
	public GameObject transition;

	public void OnCollisionEnter2D(Collision2D collision)
	{
		if(collision.gameObject.tag == "Player"){
			GetComponent<AudioSource>().clip = sound;
			GetComponent<AudioSource>().Play();
			collision.gameObject.transform.position = new Vector2(next.transform.position.x, next.transform.position.y);
		}
	}

	public void OnDrawGizmos()
	{
		if(next != null){
			Gizmos.DrawLine(transform.position, next.transform.position);
			Gizmos.DrawIcon(next.transform.position, "d_P4_DeletedLocal");
		}
	}

}

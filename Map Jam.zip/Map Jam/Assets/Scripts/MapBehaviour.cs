﻿using System.Collections.Generic;
using UnityEngine;

public class MapBehaviour : MonoBehaviour
{
   
// private:
	private const float camera_scale_x = 9*2;
	private const float camera_scale_y = 5*2;
	private const float index = 1;
	private Vector2 scale;	// map scale
	private Vector2 rel;	// relation of map scale and camera scale
	private Vector3 offset;	// map offset position
	private AudioSource audio;
	private Vector3 door_position;
	private Color color;
	
	private Vector2 rel_calculation(float x, float y){
		// calculate the relation beetwen the map scale and camera scale
		return new Vector2(
			x / camera_scale_x,
			y / camera_scale_y
		);
	}
	private void Start()
	{
		color = GetComponent<SpriteRenderer>().color;

		scale = transform.localScale;
		offset = transform.position;
		audio = GetComponent<AudioSource>();

		rel = rel_calculation(scale.x,scale.y);

		player_position = Instantiate(player_position, map_position(GameObject.Find("Player").transform.position), Quaternion.identity) as GameObject;
		player_position.transform.SetParent(this.gameObject.transform);
	}
	private void Update()
	{

		if (audio.isPlaying) GetComponent<SpriteRenderer>().color = color - new Color(0.15f,0.15f,0.15f, 0);
		else GetComponent<SpriteRenderer>().color = color;

		if (Input.GetMouseButtonDown(0)) click(Input.mousePosition);
	}
	private bool inside_map(Vector3 point){+
		// return true if the point is inside the map, false otherwise
		bool x = (point.x < (scale.x / 2) + offset.x) && (point.x > -(scale.x / 2) + offset.x);
		bool y = (point.y < (scale.y / 2) + offset.y) && (point.y > -(scale.y / 2) + offset.y);
		return (x && y);
	}
	private void set_tone(Vector3 mousePosition){
		// change the tone by the distance of the mousePosition and the door_position
		// distance:
		float distance = Mathf.Abs(Vector3.Distance(map_position(door_position), map_position(mousePosition)));
		// tone by distance:
		audio.pitch = 1 / (distance * index);	// index is a const value that set the priority of the distance in the formula
	}
	private void click(Vector3 mousePosition){
		mousePosition = Camera.main.ScreenToWorldPoint(mousePosition);
		if (inside_map(mousePosition)){
			set_tone(mousePosition);
			audio.clip = clips[0];
			audio.Play();
		}
		
	}

// public:
	public List<AudioClip> clips;
	public GameObject player_position;

	public Vector3 map_position(Vector3 position)
	{
		// Return a camera position into a map position
		Vector3 pos = new Vector3(
			rel.x * (position.x - offset.x),
			rel.y * (position.y - offset.y),
			-1
		) + offset;

		return pos;

	}
	public void modifie_door_position(Vector3 new_pos) {
		// when u pass to a next room or level u need to change the next door to get the new "set_tone" formula
		door_position = new_pos;
	}

}
